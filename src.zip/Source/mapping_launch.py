from launch import LaunchDescription
from launch_ros.actions import Node
import os

def generate_launch_description():
    lua_config_dir = os.path.expanduser('~/unitree_ws')
    lua_config_file = 'my_rover.lua'

    return LaunchDescription([
        # 1. Cartographer Node
        Node(
            package='cartographer_ros',
            executable='cartographer_node',
            name='cartographer_node',
            output='screen',
            parameters=[{'use_sim_time': False}],
            arguments=['-configuration_directory', lua_config_dir,
                       '-configuration_basename', lua_config_file],
            remappings=[('/scan', '/scan')]
        ),

        # 2. Occupancy Grid (This creates the /map)
        Node(
            package='cartographer_ros',
            executable='cartographer_occupancy_grid_node',
            name='cartographer_occupancy_grid_node',
            parameters=[{'resolution': 0.05}],
            arguments=['-publish_period_sec', '1.0']
        ),

        # 3. ONLY ONE STATIC TRANSFORM: odom -> lidar
        # DO NOT provide map -> odom here. Cartographer does that itself.
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            arguments=['0', '0', '0', '0', '0', '0', 'odom', 'unilidar_lidar']
        ),
    ])
